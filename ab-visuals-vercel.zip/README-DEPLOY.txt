AB VISUALS — VERCEL DEPLOY (2 minute, no coding)
================================================

NOTE: Website ka built-in database SUPABASE hai (jo kaam "firebase"
bolte hain wo yahi hai) — wo connect karne ke steps STEP 2 me hain,
sirf 3 copy-paste. Admin panel ka button aur SQL dono ready hain.

STEP 1 — Site LIVE karo (abhi, bina database ke bhi chalega)
------------------------------------------------------------
1. https://vercel.com kholo aur login karo
2. Dashboard pe "Add New..." → "Project" → is zip ko EXTRACT karke
   folder ko drag-drop karo (ya zip ko hi drop karo)
3. Deploy dabao — bas! Site live hai: https://tumhara-name.vercel.app

   ADMIN PANEL: https://tumhara-name.vercel.app/amit231106
   (default passcode: amit231106)

   Is stage pe site poori chalti hai — admin panel se demo projects,
   photos, text sab edit kar sakte ho, par wo edits sirf TUMHARE
   browser me save hote hain (local preview mode).

STEP 2 — Supabase connect karo (EK BAAR — iske baad sabko dikhega)
------------------------------------------------------------------
Ye database tumhare apne free Supabase account me banta hai
(bilkul waise hi jaise YouTube channel tumhara hi hota hai).
Total 3 copy-paste, ~2 minute:

1. https://supabase.com kholo → "Start your project" → Google se sign-up
   → "New project" → koi bhi naam (jaise ab-visuals) → Create
   (database banne me 1-2 minute lagte hain, wait karo)

2. Apni site ka admin panel kholo: /amit231106 → Tab 4 "Cloud & Security"
   - Supabase me: Settings → API → "Project URL" copy karo
   - Admin panel ke "Project URL" box me paste karo
   - Usi page se "anon public" key copy karke "Anon Key" box me paste karo

3. Admin panel me "Open my Supabase SQL Editor" link pe click karo
   → wahan admin panel ke SQL box ka poora SQL paste karo (Copy SQL button)
   → RUN dabao. ("Success" aayega — ye tables + photo storage banata hai)

4. Admin panel me wapas aao → "Test & Connect" dabao
   → "Supabase connected!" dikhega (khali project me demo projects
   apne aap seed ho jayenge)

5. "Download Cloud Build" dabao → ek nayi index.html download hogi
   (ye wahi site hai jisme database keys bake ho chuki hain)

6. Vercel dashboard → apna project kholo → is nayi index.html ko
   drag-drop karke redeploy karo (ya purani index.html replace karo)

DONE! Ab admin panel ki HAR edit — projects, photos, text, delete,
reorder — sab devices ke sab visitors ko turant dikhegi (live sync).

LAST THING — Security
---------------------
Admin panel me Tab 4 → "Admin Passcode" se passcode zaroor change karo
(default amit231106 mat rakhna).
